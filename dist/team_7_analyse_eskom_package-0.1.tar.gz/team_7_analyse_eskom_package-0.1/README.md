# mypackage 
---

This library is Python package that contain a function that returns the top number (top_n) of items in an array, in descending order.

## Building this package locally
---- 
<span style="color: gray;">python setup.py sdist</span> 


## Installing this package from Github
----
<span style="color: gray;">pip git+https://github.com/bmqhamane/team_7_analyse_eskom.git</span> 

### Updating this package from Github
----
<span style="color: gray;">pip install --upgrade git+https://github.com/bmqhamane/team_7_analyse_eskom.git</span> 

License
MIT